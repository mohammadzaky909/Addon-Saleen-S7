         NFS MW ADDON SALEEN S7
           By Muhammad Zaky


Add Car to Nfs MW

 Step 1
-extract Files Saleen S7 Addon

Step 2
-copy Folder S7 in CARS Folder
To Nfs MW Directory

Step 3
-copy Folder Config And Resources in folder ED files
To Ed car dealer (Ed v1.0.0.800)
 
Step 4
-open Ed Car Dealer and open folder Nfs Mw directory
You can see s7 file In Ed Car Dealer, you open tool menu
You press Button unlocking game files for modding,You wait 
until there is information successfully unlocked game files
For modding If so, press add car, If so, just save but
don't enter the game yet.

Add modscript Car to Nfs MW 

Step 1

Open NFS VLTed (You can open it by running as administrator)

Step 2
Open the NFS MW game folder in your directory
(Make sure the game folder is read by the NFS VLTed application),

Step 3
open the file menu, press import and Modscript. 
After that, select the s7.NFSMS file,

Step 4
After that, press Install modscript 
and wait until the installation is complete,
After the installation is complete, press the file menu and save directly.Finish





 